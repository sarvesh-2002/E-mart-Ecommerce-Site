-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: May 23, 2021 at 07:39 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `emart_order_data`
--

-- --------------------------------------------------------

--
-- Table structure for table `krishna62`
--

CREATE TABLE `krishna62` (
  `id` int(11) NOT NULL,
  `img_name` varchar(30) NOT NULL,
  `gadget_type` varchar(30) NOT NULL,
  `model_type` varchar(100) NOT NULL,
  `model_name` varchar(100) NOT NULL,
  `prod_id` varchar(20) NOT NULL,
  `prod_price` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `user62`
--

CREATE TABLE `user62` (
  `id` int(11) NOT NULL,
  `img_name` varchar(30) NOT NULL,
  `gadget_type` varchar(30) NOT NULL,
  `model_type` varchar(100) NOT NULL,
  `model_name` varchar(100) NOT NULL,
  `prod_id` varchar(20) NOT NULL,
  `prod_price` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user62`
--

INSERT INTO `user62` (`id`, `img_name`, `gadget_type`, `model_type`, `model_name`, `prod_id`, `prod_price`) VALUES
(1, 'aceraspire5_1-1.jpeg', 'Laptop', 'Acer', 'Aspire 5', '5', 37990),
(2, 'strontiumnitroammo_1.jpeg', 'Accessories', 'Pendrive', 'Strontium Nitro Ammo', '6', 575);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `krishna62`
--
ALTER TABLE `krishna62`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user62`
--
ALTER TABLE `user62`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `krishna62`
--
ALTER TABLE `krishna62`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user62`
--
ALTER TABLE `user62`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
