-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: May 23, 2021 at 04:18 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mobile_database`
--

-- --------------------------------------------------------

--
-- Table structure for table `oneplus`
--

CREATE TABLE `oneplus` (
  `Id` int(50) NOT NULL,
  `Gadget_Type` varchar(50) NOT NULL,
  `Model_Type` varchar(50) NOT NULL,
  `Model_Name` varchar(50) NOT NULL,
  `Img_Name` varchar(50) NOT NULL,
  `product_price` varchar(10) NOT NULL,
  `RAM` varchar(50) NOT NULL,
  `Internal_Storage` varchar(50) NOT NULL,
  `Expandable_Memory` varchar(50) NOT NULL,
  `Display_Size` varchar(50) NOT NULL,
  `Primary_Camera` varchar(50) NOT NULL,
  `Secondary_Camera` varchar(50) NOT NULL,
  `Android_System` varchar(50) NOT NULL,
  `Battery` varchar(50) NOT NULL,
  `Processor_Type` varchar(50) NOT NULL,
  `Network_Type` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `oneplus`
--

INSERT INTO `oneplus` (`Id`, `Gadget_Type`, `Model_Type`, `Model_Name`, `Img_Name`, `product_price`, `RAM`, `Internal_Storage`, `Expandable_Memory`, `Display_Size`, `Primary_Camera`, `Secondary_Camera`, `Android_System`, `Battery`, `Processor_Type`, `Network_Type`) VALUES
(1, 'Mobile', 'Oneplus', '8pro5g', '8pro5g_1-1.jpg', '50499', '12GB', '256GB', '1TB', '6.7 inch', '48MP+8MP+ 48MP+5MP Multi Role Quad Camera', '32MP Selfie Camera', 'Android 11.0', '4510 mAH', 'Qualcomm Snapdragon 865', 'Dual-Standby (5G+5G)'),
(2, 'Mobile', 'Oneplus', '8t5g', '8t5g_1-1.jpg', '39499', '12GB', '256GB', '1TB', '6.7 inch', '48MP + 16MP + 5MP + 2MP Quad rear Camera', '16MP Selfie Camera', 'Android 11.0', '4500 mAH', 'Qualcom Snapdragon 865', 'Dual-Standby (5G+5G)'),
(3, 'Mobile', 'Oneplus', 'nord5g', 'nord5g_1-1.jpg', '29999', '12GB', '256GB', '1TB', '6.7 inch', '48MP+5MP+ 48MP+2MP Multi Role Quad Camera', '16MP Selfie Camera', 'Android 11.0', '6000 mAH', 'Qualcomm Snapdragon 450 (1.8GHz Octa-core)', 'Dual-Standby (5G+5G)');

-- --------------------------------------------------------

--
-- Table structure for table `oppo`
--

CREATE TABLE `oppo` (
  `Id` int(50) NOT NULL,
  `Gadget_Type` varchar(50) NOT NULL,
  `Model_Type` varchar(50) NOT NULL,
  `Model_Name` varchar(50) NOT NULL,
  `Img_Name` varchar(50) NOT NULL,
  `product_price` varchar(10) NOT NULL,
  `RAM` varchar(50) NOT NULL,
  `Internal_Storage` varchar(50) NOT NULL,
  `Expandable_Memory` varchar(50) NOT NULL,
  `Display_Size` varchar(50) NOT NULL,
  `Primary_Camera` varchar(50) NOT NULL,
  `Secondary_Camera` varchar(50) NOT NULL,
  `Android_System` varchar(50) NOT NULL,
  `Battery` varchar(50) NOT NULL,
  `Processor_Type` varchar(50) NOT NULL,
  `Network_Type` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `oppo`
--

INSERT INTO `oppo` (`Id`, `Gadget_Type`, `Model_Type`, `Model_Name`, `Img_Name`, `product_price`, `RAM`, `Internal_Storage`, `Expandable_Memory`, `Display_Size`, `Primary_Camera`, `Secondary_Camera`, `Android_System`, `Battery`, `Processor_Type`, `Network_Type`) VALUES
(1, 'Mobile', 'Oppo', 'A11k', 'a11k_1-1.jpeg', '8490', '2GB', '32GB', '256GB', '6.2 inch', '13MP+2MP Dual rear Camera', '5MP Selfie Camera', 'Android 9.0', '4230 mAH', 'Mediatek Helio P35', 'Dual-Standby (4G+4G)'),
(2, 'Mobile', 'Oppo', 'A15', 'a15_1-1.jpeg', '9990', '3GB', '32GB', '256GB', '6.5 inch', '13MP + 2MP + 2MP Triple rear Camera', '5MP Selfie Camera', 'Android ', '4230 mAH', 'Mediatek Helio P35', 'Dual-Standby (4G+4G)'),
(3, 'Mobile', 'Oppo', 'A31', 'a31_1-1.jpeg', '9990', '4GB', '64GB', '256GB', '6.5 inch', '12MP+2MP+2MP Triple rear Camera', '8MP Selfie Camera', 'Android ', '4230 mAH', 'Mediatek MT6765', 'Dual-Standby (4G+4G)'),
(4, 'Mobile', 'Oppo', 'A52', 'a52_1-1.jpeg', '14990', '6GB', '128GB', '256GB', '6.5 inch', '12MP + 8MP + 2MP + 2MP Quad rear Camera', '16MP Selfie Camera', 'Android Pie v10.0', '5000 mAH', 'Qualcom Snapdragon 665', 'Dual-Standby (4G+4G)'),
(5, 'Mobile', 'Oppo', 'A53', 'a53_1-1.jpeg', '12990', '8GB', '128GB', '256GB', '6.5 inch', '12MP+2MP+2MP Triple rear Camera', '16MP Selfie Camera', 'Android ', '5000 mAH', 'Qualcomm Snapdragon 450', 'Dual-Standby (4G+4G)'),
(6, 'Mobile', 'Oppo', 'F17', 'f17_1-1.jpeg', '16600', '6GB', '128GB', '256GB', '6.4 inch', '16MP Quad camera', '16MP Selfie Camera', 'Android Pie v10.0', '5000 mAH', 'Qualcom Snapdragon 665', 'Dual-Standby (4G+4G)'),
(7, 'Mobile', 'Oppo', 'F19pro', 'f19pro_1-1.jpeg', '21490', '8GB', '128GB', '256GB', '6.4 inch', '48MP+5MP+ 2MP+2MP Multi Role Quad Camera', '13MP Selfie Camera', 'Android 11.0', '4310 mAH', 'Qualcomm Snapdragon 730G', 'Dual-Standby (4G+4G)'),
(8, 'Mobile', 'Oppo', 'F19pro5g', 'f19pro5g_1-1.jpeg', '25590', '8GB', '128GB', '1TB', '6.4 inch', '48MP Quad Camera', '13MP Selfie Camera', 'Android 11.0', '4310 mAH', 'Mediatek Dimensty 5g', 'Dual-Standby (4G+4G)');

-- --------------------------------------------------------

--
-- Table structure for table `redmi`
--

CREATE TABLE `redmi` (
  `Id` int(50) NOT NULL,
  `Gadget_Type` varchar(50) NOT NULL,
  `Model_Type` varchar(50) NOT NULL,
  `Model_Name` varchar(50) NOT NULL,
  `Img_Name` varchar(50) NOT NULL,
  `product_price` varchar(10) NOT NULL,
  `RAM` varchar(50) NOT NULL,
  `Internal_Storage` varchar(50) NOT NULL,
  `Expandable_Memory` varchar(50) NOT NULL,
  `Display_Size` varchar(50) NOT NULL,
  `Primary_Camera` varchar(50) NOT NULL,
  `Secondary_Camera` varchar(50) NOT NULL,
  `Android_System` varchar(50) NOT NULL,
  `Battery` varchar(50) NOT NULL,
  `Processor_Type` varchar(50) NOT NULL,
  `Network_Type` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `redmi`
--

INSERT INTO `redmi` (`Id`, `Gadget_Type`, `Model_Type`, `Model_Name`, `Img_Name`, `product_price`, `RAM`, `Internal_Storage`, `Expandable_Memory`, `Display_Size`, `Primary_Camera`, `Secondary_Camera`, `Android_System`, `Battery`, `Processor_Type`, `Network_Type`) VALUES
(1, 'Mobile', 'Redmi', 'note9pro', 'note9pro_1-1.jpeg', '12999', '6GB', '128GB', '1TB', '6.5 inch', '48MP+5MP+ 2MP+2MP Multi Role Quad Camera', '20MP Selfie Camera', 'Android 11.0', '5020 mAH', 'Qualcomm Snapdragon 730G', 'Dual-Standby (4G+4G)'),
(2, 'Mobile', 'Redmi', '9', 'redmi9_1-1.jpeg', '87999', '3GB', '32GB', '256GB', '6.4 inch', '13MP + 2MP + 2MP Triple rear Camera', '5MP Selfie Camera', 'Android 8.1', '4310 mAH', 'Mediatek Helio G35', 'Dual-Standby (4G+4G)'),
(3, 'Mobile', 'Redmi', '9a', 'redmi9a_1-1.jpeg', '6799', '3GB', '32GB', '256GB', '6.5 inch', '13MP+2MP+2MP Triple rear Camera', '8MP Selfie Camera', 'Android v10.0', '5000 mAH', 'Mediatek Helio G35', 'Dual-Standby (4G+4G)'),
(4, 'Mobile', 'Redmi', '9power', 'redmi9power_1-1.jpeg', '10499', '3GB', '32GB', '64GB', '6.4 inch', '16MP Quad camera', '13MP Selfie Camera', 'Android 11.0', '5000 mAH', 'Qualcom Snapdragon 662', 'Dual-Standby (4G+4G)'),
(5, 'Mobile', 'Redmi', '9prime', 'redmi9prime_1-1.jpeg', '9499', '4GB', '64GB', '256GB', '6.5 inch', '12MP+2MP+2MP Triple rear Camera', '8MP Selfie Camera', 'Android 10.0', '5000 mAH', 'Qualcomm Snapdragon 730G', 'Dual-Standby (4G+4G)'),
(6, 'Mobile', 'Redmi', 'note9', 'redminote9_1-1.jpeg', '10999', '4GB', '64GB', '256GB', '6.5 inch', '48MP Quad Camera', '16MP Selfie Camera', 'Android 11.0', '5000 mAH', 'Qualcom Snapdragon 665', 'Dual-Standby (4G+4G)'),
(7, 'Mobile', 'Redmi', 'note9promax', 'note9promax_1-1.jpeg', '14999', '6GB', '128GB', '128GB', '6.5 inch', '48MP+5MP+ 2MP+2MP Multi Role Quad Camera', '16MP Selfie Camera', 'Android 10.0', '6000 mAH', 'Exynos 9611,2.3GHz,1.7GHz octa-core processor', 'Dual-Standby (4G+4G)');

-- --------------------------------------------------------

--
-- Table structure for table `samsung`
--

CREATE TABLE `samsung` (
  `Id` int(50) NOT NULL,
  `Gadget_Type` varchar(50) NOT NULL,
  `Model_Type` varchar(50) NOT NULL,
  `Model_Name` varchar(50) NOT NULL,
  `Img_Name` varchar(50) NOT NULL,
  `product_price` varchar(10) NOT NULL,
  `RAM` varchar(50) NOT NULL,
  `Internal_Storage` varchar(50) NOT NULL,
  `Expandable_Memory` varchar(50) NOT NULL,
  `Display_Size` varchar(50) NOT NULL,
  `Primary_Camera` varchar(50) NOT NULL,
  `Secondary_Camera` varchar(50) NOT NULL,
  `Android_System` varchar(50) NOT NULL,
  `Battery` varchar(50) NOT NULL,
  `Processor_Type` varchar(50) NOT NULL,
  `Network_Type` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `samsung`
--

INSERT INTO `samsung` (`Id`, `Gadget_Type`, `Model_Type`, `Model_Name`, `Img_Name`, `product_price`, `RAM`, `Internal_Storage`, `Expandable_Memory`, `Display_Size`, `Primary_Camera`, `Secondary_Camera`, `Android_System`, `Battery`, `Processor_Type`, `Network_Type`) VALUES
(1, 'Mobile', 'Samsung Galaxy', 'A12', 'a12_1-1.jpeg', '12999', '4GB', '64GB', '1TB', '6.5 inch', '48MP+5MP+ 2MP+2MP Multi Role Quad Camera', '8MP Selfie Camera', 'Android 10.0', '5000 mAH', '1.8GHz / 2.3GHz Octa-core', 'Dual-Standby (4G+4G)'),
(2, 'Mobile', 'Samsung Galaxy', 'M02', 'm02_1-1.jpeg', '6999', '4GB', '64GB', '1TB', '6.5 inch', '13MP+2MP+2MP Triple rear Camera', '5MP Selfie Camera', 'Android Pie 10.0', '5000 mAH', 'Mediatek', 'Dual-Standby (4G+4G)'),
(3, 'Mobile', 'Samsung Galaxy', 'M02s', 'm02s_1-1.jpeg', '8999', '4GB', '64GB', '1TB', '6.5 inch', '13MP+2MP+2MP Triple rear Camera', '5MP Selfie Camera', 'Android Pie 10.0', '5000 mAH', 'Qualcomm Snapdragon 450 (1.8GHz Octa-core)', 'Dual-Standby (4G+4G)'),
(4, 'Mobile', 'Samsung Galaxy', 'M11', 'm11_1-1.jpeg', '9999', '4GB', '64GB', '512GB', '6.4 inch', '13MP+5MP+2MP Depth rear Camera', '8MP Selfie Camera', 'Android v10.0', '5000 mAH', 'Qualcomm Snapdragon 450 (1.8GHz Octa-core)', 'Dual-Standby (4G+4G)'),
(5, 'Mobile', 'Samsung Galaxy', 'M21', 'm21_1-1.jpeg', '13999', '4GB', '64GB', '512GB', '6.4 inch', '48MP+8MP+5MP Triple rear Camera', '20MP Selfie Camera', 'Android 10.0', '6000 mAH', 'Exynos 9611,2.3GHz,1.7GHz octa-core processor', 'Dual-Standby (4G+4G)'),
(6, 'Mobile', 'Samsung Galaxy', 'M31s', 'm31s_1-1.jpeg', '18499', '6GB', '128GB', '512GB', '6.5 inch', '64MP+12MP+ 5MP+5MP Quad Camera', '32MP Selfie Camera', 'Android 11.0', '6000 mAH', 'Exynos 9611 octa-core processor', 'Dual-Standby (4G+4G)'),
(7, 'Mobile', 'Samsung Galaxy', 'M51', 'm51_1-1.jpeg', '21749', '8GB', '128GB', '512GB', '6.7 inch', '64MP+12MP+ 5MP+5MP Quad Camera', '32MP Selfie Camera', 'Android 11.0', '7000 mAH', 'Qualcomm Snapdragon 730G', 'Dual-Standby (4G+4G)'),
(8, 'Mobile', 'Samsung Galaxy', 'Note10lite', 'note10lite_1-1.jpeg', '27999', '6GB', '128GB', '1TB', '6.7 inch', '12MP+12MP+12MP Zoom Camera', '32MP Selfie Camera', 'Android 11.0', '4500 mAH', 'Qualcomm Snapdragon 765G 5G mobile platform', 'Dual-Standby (4G+4G)');

-- --------------------------------------------------------

--
-- Table structure for table `vivo`
--

CREATE TABLE `vivo` (
  `Id` int(50) NOT NULL,
  `Gadget_Type` varchar(50) NOT NULL,
  `Model_Type` varchar(50) NOT NULL,
  `Model_Name` varchar(50) NOT NULL,
  `Img_Name` varchar(50) NOT NULL,
  `product_price` varchar(10) NOT NULL,
  `RAM` varchar(50) NOT NULL,
  `Internal_Storage` varchar(50) NOT NULL,
  `Expandable_Memory` varchar(50) NOT NULL,
  `Display_Size` varchar(50) NOT NULL,
  `Primary_Camera` varchar(50) NOT NULL,
  `Secondary_Camera` varchar(50) NOT NULL,
  `Android_System` varchar(50) NOT NULL,
  `Battery` varchar(50) NOT NULL,
  `Processor_Type` varchar(50) NOT NULL,
  `Network_Type` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `vivo`
--

INSERT INTO `vivo` (`Id`, `Gadget_Type`, `Model_Type`, `Model_Name`, `Img_Name`, `product_price`, `RAM`, `Internal_Storage`, `Expandable_Memory`, `Display_Size`, `Primary_Camera`, `Secondary_Camera`, `Android_System`, `Battery`, `Processor_Type`, `Network_Type`) VALUES
(1, 'Mobile', 'vivo', 'v20se', 'v20se_1-1.jpeg', '11490', '8GB', '128GB', '1TB', '6.4 inch', '48MP+8MP+2MP rear Camera', '32MP Selfie Camera', 'Android 10.0', '5000 mAH', 'Qualcomm Snapdragon 665', 'Dual-Standby (4G+4G)'),
(2, 'Mobile', 'Vivo', 'y30', 'vivoy30_1-1.jpeg', '13990', '4GB', '128GB', '256GB', '6.4 inch', '13MP + 8MP + 2MP + 2MP Quad rear Camera', '8MP Selfie Camera', 'Android ', '5000 mAH', 'Mediatek Helio G35', 'Dual-Standby (4G+4G)'),
(3, 'Mobile', 'Vivo', 'y31', 'vivoy31_1-1.jpeg', '16490', '6GB', '128GB', '128GB', '6.4 inch', '48MP+2MP+2MP Triple rear Camera', '16MP Selfie Camera', 'Android 11.0', '5000 mAH', 'Exynos 9611,2.3GHz,1.7GHz octa-core processor', 'Dual-Standby (4G+4G)'),
(4, 'Mobile', 'Vivo', 'y11', 'y11_1-1.jpeg', '8990', '3GB', '32GB', '256GB', '6.4 inch', '13MP + 12MP Dual rear Camera', '8MP Selfie Camera', 'Android 8.1', '5000 mAH', 'Qualcom Snapdragon 439', 'Dual-Standby (4G+4G)'),
(5, 'Mobile', 'Vivo', 'y12s', 'y12s_1-1.jpeg', '9990', '3GB', '32GB', '256GB', '6.5 inch', '13MP+2MP rear Camera', '8MP Selfie Camera', 'Android 11.0', '5000 mAH', 'Mediatek Helio G35', 'Dual-Standby (4G+4G)'),
(6, 'Mobile', 'Vivo', 'y20series', 'y20series_1-1.jpeg', '9990', '4GB', '64GB', '256GB', '6.5 inch', '13MP + 2MP + 2MP Triple rear Camera', '8MP Selfie Camera', 'Android 11.0', '5000 mAH', 'Qualcom Snapdragon 460', 'Dual-Standby (4G+4G)'),
(7, 'Mobile', 'Vivo', 'y51series', 'y51series_1-1.jpeg', '17990', '6GB', '128GB', '256GB', '6.5 inch', '48MP+5MP+ 2MP+2MP Multi Role Quad Camera', '16MP Selfie Camera', 'Android 11.0', '6000 mAH', 'Exynos 9611,2.3GHz,1.7GHz octa-core processor', 'Dual-Standby (4G+4G)'),
(8, 'Mobile', 'Vivo', 'y91i', 'y91i_1-1.jpeg', '7490', '3GB', '32GB', '256GB', '6.5 inch', '13MP + 2MP Dual rear Camera', '8MP Selfie Camera', 'Android 8.1', '5000 mAH', 'Mediatek Helio P35', 'Dual-Standby (4G+4G)');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
