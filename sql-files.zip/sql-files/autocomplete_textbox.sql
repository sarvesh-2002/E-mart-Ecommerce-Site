-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: May 23, 2021 at 04:21 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `autocomplete_textbox`
--

-- --------------------------------------------------------

--
-- Table structure for table `ajax_autocomplete_textbox`
--

CREATE TABLE `ajax_autocomplete_textbox` (
  `Product` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ajax_autocomplete_textbox`
--

INSERT INTO `ajax_autocomplete_textbox` (`Product`) VALUES
('Mobile'),
('Laptop'),
('Samsung'),
('Oppo'),
('Vivo'),
('Redmi'),
('Oneplus'),
('Acer'),
('Dell'),
('Hp'),
('Asus'),
('Accessories'),
('Data Cables'),
('Mobile Chargers'),
('Earphones'),
('Powerbanks'),
('Pendrive'),
('Television'),
('Kitchen Appliance'),
('Mixer Grinder'),
('Juicer'),
('Induction'),
('Microwave Oven');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
