-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: May 23, 2021 at 04:20 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `television_database`
--

-- --------------------------------------------------------

--
-- Table structure for table `32inches`
--

CREATE TABLE `32inches` (
  `id` int(50) NOT NULL,
  `gadget_type` varchar(50) NOT NULL,
  `model_type` varchar(50) NOT NULL,
  `model_name` varchar(30) NOT NULL,
  `folder_name` varchar(50) NOT NULL,
  `img_name` varchar(50) NOT NULL,
  `inches` varchar(50) NOT NULL,
  `prod_price` varchar(50) NOT NULL,
  `display_size` varchar(50) NOT NULL,
  `color` varchar(50) NOT NULL,
  `screen_type` varchar(50) NOT NULL,
  `hdmi` varchar(50) NOT NULL,
  `usb` varchar(50) NOT NULL,
  `processor` varchar(50) NOT NULL,
  `storage_memory` varchar(50) NOT NULL,
  `speaker_type` varchar(50) NOT NULL,
  `internet_access` varchar(50) NOT NULL,
  `dimension` varchar(50) NOT NULL,
  `Warranty` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `32inches`
--

INSERT INTO `32inches` (`id`, `gadget_type`, `model_type`, `model_name`, `folder_name`, `img_name`, `inches`, `prod_price`, `display_size`, `color`, `screen_type`, `hdmi`, `usb`, `processor`, `storage_memory`, `speaker_type`, `internet_access`, `dimension`, `Warranty`) VALUES
(1, 'television', 'compaq', 'Compaq ErSeries 80cm', 'compaqerseries80cm', 'compaqerseries_1-1.jpeg', '32', '11999', '32 inch', ' Black', 'LED', '3', '2', 'ARM Cortex - A53 64Bit', '8 GB', 'Box Speakers', 'Yes', ' 73.21 cm x 43.2 cm x 8 cm', '1 Year'),
(2, 'television', 'lg', 'LG 80cm', 'lg80cm', 'lg80cm_1-1.jpeg', '32', '16499', '80 cm (32)', ' Ceramic Black', 'LED', '2', '1', 'ARM Cortex - A53 64Bit', '4 GB', 'DTS Virtual:X', 'Yes', '73.9 cm x 8.4 cm', '1 Year'),
(3, 'television', 'mi', 'Mi 4Apro', 'mi4apro', 'mi4apro_1-1.jpeg', '32', '14999', '32 inch', ' Black', 'LED', '3', '2', 'Amlogic 64-bit Quad-core', '8 GB', 'Stereo', 'Yes', '733 mm x 435 mm x 80 mm', '1 Year'),
(4, 'television', 'oneplus', 'OnePlus YSeries 80cm', 'oneplusyseries80cm', 'oneplusyseries80cm_1-1.jpeg', '32', '15499', '80 cm (32)', 'Black', 'LED', '2', '2', 'MTK 6683', '8 GB', 'Box', 'Yes', '713 mm x 42 mm', '1 Year'),
(5, 'television', 'panasonic', 'Panasonic 80cm', 'panasonic80cm', 'panasonic80cm_1-1.jpeg', '32', '22541', '32 inch', ' Black', 'LED', '3', '2', 'No', 'No', ' Audio Booster+', 'Yes', '733.4 mm x 78 mm', '1 Year'),
(6, 'television', 'realme', 'Realme 80cm', 'realme80cm', 'realme80cm_1-1.jpeg', '32', '15999', '80 cm (32)', ' Black', 'LED', '3', '2', 'MediaTek Quad core 6883', '8 GB', 'Box Speakers', 'Yes', '730 mm x 432 mm x 88 mm', '1 Year'),
(7, 'television', 'samsung', 'Samsung 80cm', 'samsung80cm', 'samsung80cm_1-1.jpeg', '32', '17999', '80 cm (32)', 'Black', 'LED', '2', '1', 'No', 'No', 'Box', 'Yes', '73.74 cm x 43.8 cm x 7.4 cm', '1 Year'),
(8, 'television', 'sonybravia', 'Sony Bravia 80cm', 'sonybravia80cm', 'sonybravia80cm_1-1.jpeg', '32', '19989', '32 inch', ' Black', 'LED', '2', '1', 'No', 'No', 'Box Speakers', 'No', '72.9 cm x 43.6 cm x 7.3 cm', '1 Year');

-- --------------------------------------------------------

--
-- Table structure for table `38inches`
--

CREATE TABLE `38inches` (
  `id` int(50) NOT NULL,
  `gadget_type` varchar(50) NOT NULL,
  `model_type` varchar(50) NOT NULL,
  `model_name` varchar(30) NOT NULL,
  `folder_name` varchar(50) NOT NULL,
  `img_name` varchar(50) NOT NULL,
  `inches` varchar(50) NOT NULL,
  `prod_price` varchar(50) NOT NULL,
  `display_size` varchar(50) NOT NULL,
  `color` varchar(50) NOT NULL,
  `screen_type` varchar(50) NOT NULL,
  `hdmi` varchar(50) NOT NULL,
  `usb` varchar(50) NOT NULL,
  `processor` varchar(50) NOT NULL,
  `storage_memory` varchar(50) NOT NULL,
  `speaker_type` varchar(50) NOT NULL,
  `internet_access` varchar(50) NOT NULL,
  `dimension` varchar(50) NOT NULL,
  `Warranty` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `38inches`
--

INSERT INTO `38inches` (`id`, `gadget_type`, `model_type`, `model_name`, `folder_name`, `img_name`, `inches`, `prod_price`, `display_size`, `color`, `screen_type`, `hdmi`, `usb`, `processor`, `storage_memory`, `speaker_type`, `internet_access`, `dimension`, `Warranty`) VALUES
(1, 'television', 'cloudwalker', 'Cloudwalker Spectra', 'cloudwalkerspectra', 'cloudwalkerspectra_1-1.jpeg', '38', '14999', '100 cm (39)', ' Black', 'LED', '2', '2', 'No', 'No', 'Box Speakers', 'No', '890 mm x 528 mm x 89 mm', '1 Year'),
(2, 'television', 'impex', 'Impex', 'impex', 'impex_1-1.jpeg', '38', '19039', '100 cm (39)', 'Black', 'LED', '2', '2', 'No', 'No', 'Box', 'No', '910 mm x 65 mm', '3 Year'),
(3, 'television', 'jvc', 'Jvc', 'jvc', 'jvc_1-1.jpeg', '38', '16499', '98 cm (39)', ' Black', 'LED', '2', '2', 'No', 'No', 'Box Speakers', 'No', '880 mm x 617 mm x 70 mm', '1 Year'),
(4, 'television', 'lg', 'Lg LM63', 'lglm63', 'lglm63_1-1.jpeg', '38', '17999', '100 cm (39)', 'Black', 'LED', '3', '2', 'Quad Core Processor', '4 GB', ' Down Firing', 'Yes', '736 mm x 82.9 mm', '1 Year'),
(5, 'television', 'oneplus', 'OnePlus Q1Series', 'oneplusq1series', 'oneplusq1series_1-1.jpeg', '38', '62499', '38 inch', ' Black', 'QLED', '4', '2', 'MTK5670', '16 GB', 'Box Speakers', 'Yes', '1223.7 mm x 61.3 cm x 707 mm', '1 Year'),
(6, 'television', 'panasonic', 'Panasonic', 'panasonic', 'panasonic_1-1.jpeg', '38', '29999', '100 cm (39)', 'Black', 'LED', '2', '2', 'ARM CA53 Quad Core with TEE and Secure Boot', '8 GB', 'Box', 'Yes', '89.36 cm x 8.5 cm', '1 Year'),
(7, 'television', 'samsung', 'Samsung Theframe', 'samsungtheframe', 'samsungtheframe_1-1.jpeg', '38', '64999', '100 cm (39)', ' Black', 'LED', '4', '2', 'No', '8 GB', 'Box Speakers', 'Yes', '112.12 cm x 64.23 cm x 4.58 cm', '1 Year'),
(8, 'television', 'sonybravia', 'Sonybravia 7400h', 'sonybravia7400h', 'sonybravia7400h_1-1.jpeg', '38', '75999', '100 cm (39)', 'Black', 'LED', '3', '2', '4K Processor X1', '16 GB', 'Bass Reflex Speaker', 'Yes', '124.1 cm x 72.1 cm x 7.9 cm', '1 Year');

-- --------------------------------------------------------

--
-- Table structure for table `42inches`
--

CREATE TABLE `42inches` (
  `id` int(50) NOT NULL,
  `gadget_type` varchar(50) NOT NULL,
  `model_type` varchar(50) NOT NULL,
  `model_name` varchar(30) NOT NULL,
  `folder_name` varchar(50) NOT NULL,
  `img_name` varchar(50) NOT NULL,
  `inches` varchar(50) NOT NULL,
  `prod_price` varchar(50) NOT NULL,
  `display_size` varchar(50) NOT NULL,
  `color` varchar(50) NOT NULL,
  `screen_type` varchar(50) NOT NULL,
  `hdmi` varchar(50) NOT NULL,
  `usb` varchar(50) NOT NULL,
  `processor` varchar(50) NOT NULL,
  `storage_memory` varchar(50) NOT NULL,
  `speaker_type` varchar(50) NOT NULL,
  `internet_access` varchar(50) NOT NULL,
  `dimension` varchar(50) NOT NULL,
  `Warranty` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `42inches`
--

INSERT INTO `42inches` (`id`, `gadget_type`, `model_type`, `model_name`, `folder_name`, `img_name`, `inches`, `prod_price`, `display_size`, `color`, `screen_type`, `hdmi`, `usb`, `processor`, `storage_memory`, `speaker_type`, `internet_access`, `dimension`, `Warranty`) VALUES
(1, 'television', 'iffalcon', 'Iffalcon', 'iffalcon', 'iffalcon_1-1.jpeg', '42', '29999', '106 cm (42)', ' Black', 'DLED', '2', '1', 'Amlogic 64bit A55x4 900MHz~1.1GHz', '16 GB', 'Box Speakers', 'Yes', '97 cm x 568 mm x 7.51 cm', '1 Year'),
(2, 'television', 'lg', 'LG 106cm', 'lg106cm', 'lg106cm_1-1.jpeg', '42', '34999', '106 cm (42)', 'Black', 'LED', '3', '2', 'Quad Core Processor', '4 GB', 'Box', 'Yes', '975 mm x 80.3 mm', '1 Year'),
(3, 'television', 'oneplus', 'OnePlus YSeries 106cm', 'oneplusyseries106cm', 'oneplusyseries106cm_1-1.jpeg', '42', '25999', '106 cm (42)', ' Black', 'LED', '2', '2', 'MTK 6683', '8 GB', 'Box Speakers', 'Yes', '957 mm x 56 mm', '1 Year'),
(4, 'television', 'onida', 'Onida Live Genius', 'onidalivegenius', 'onidalivegenius_1-1.jpeg', '42', '29799', '106 cm (42)', 'Black', 'LED', '3', '2', 'No', 'No', 'Box', 'Yes', '65.3 cm x 8.1 cm', '1 Year'),
(5, 'television', 'panasonic', 'Panasonic 106cm', 'panasonic106cm', 'panasonic106cm_1-1.jpeg', '42', '41999', '106 cm (42)', ' Black', 'LED', '3', '2', 'No', 'No', 'Box Speakers', 'Yes', '974 mm x 80 mm', '1 Year'),
(6, 'television', 'samsung', 'Samsung 106cm', 'samsung106cm', 'samsung106cm_1-1.jpeg', '42', '32180', '106 cm (42)', 'Black', 'LED', '2', '1', 'No', 'No', 'Box', 'Yes', ' 97.99 cm x 57.19 cm x 7.73 cm', '1 Year'),
(7, 'television', 'sony', 'Sony 106cm', 'sony106cm', 'sony106cm_1-1.jpeg', '42', '40999', '106 cm (42)', ' Black', 'LED', '3', '3', 'No', 'No', 'Box Speakers', 'Yes', '97 cm x 5.7 cm', '1 Year'),
(8, 'television', 'thomsan', 'Thomsan 9a Series', 'thomsan9aseries', 'thomsan9aseries_1-1.jpeg', '42', '20999', '106 cm (42)', 'Black', 'LED', '3', '2', 'ARM Cortex-A53', '8 GB', 'Box', 'Yes', '954 mm x 540 mm x 90 mm', '1 Year');

-- --------------------------------------------------------

--
-- Table structure for table `50inches`
--

CREATE TABLE `50inches` (
  `id` int(50) NOT NULL,
  `gadget_type` varchar(50) NOT NULL,
  `model_type` varchar(50) NOT NULL,
  `model_name` varchar(30) NOT NULL,
  `folder_name` varchar(50) NOT NULL,
  `img_name` varchar(50) NOT NULL,
  `inches` varchar(50) NOT NULL,
  `prod_price` varchar(50) NOT NULL,
  `display_size` varchar(50) NOT NULL,
  `color` varchar(50) NOT NULL,
  `screen_type` varchar(50) NOT NULL,
  `hdmi` varchar(50) NOT NULL,
  `usb` varchar(50) NOT NULL,
  `processor` varchar(50) NOT NULL,
  `storage_memory` varchar(50) NOT NULL,
  `speaker_type` varchar(50) NOT NULL,
  `internet_access` varchar(50) NOT NULL,
  `dimension` varchar(50) NOT NULL,
  `Warranty` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `50inches`
--

INSERT INTO `50inches` (`id`, `gadget_type`, `model_type`, `model_name`, `folder_name`, `img_name`, `inches`, `prod_price`, `display_size`, `color`, `screen_type`, `hdmi`, `usb`, `processor`, `storage_memory`, `speaker_type`, `internet_access`, `dimension`, `Warranty`) VALUES
(1, 'television', 'lg', 'Lg Allinone 126cm', 'lgallinone126cm', 'lgallinone126cm_1-1.jpeg', '50', '43999', '126 cm (50)', ' Black', 'LED', '3', '3', 'No', '4 GB', 'Box Speakers', 'Yes', '113 mm x 66.3 m x 8.63 m', '1 Year'),
(2, 'television', 'mi', 'Mi 4x 126cm', 'mi4x126cm', 'mi4x126cm_1-1.jpeg', '50', '33999', '125.7 cm (50)', 'Black', 'LED', '3', '2', 'Amlogic 64-bit Quad Core', '8 GB', 'Box', 'Yes', '649.3 mm x 72 mm', '1 Year'),
(3, 'television', 'motorola', 'Motorola ZX Pro', 'motorolazxpro', 'motorolazxpro_1-1.jpeg', '50', '34999', '126 cm (50)', ' Black', 'LED', '3', '2', 'MediaTek CA53 Quad Core at 1.5 GHz', '32GB', 'Box Speakers', 'Yes', '1112.5 mm x 681.2 mm x 92 mm', '1 Year'),
(4, 'television', 'panasonic', 'Panasonic 126cm', 'panasonic126cm', 'panasonic126cm_1-1.jpeg', '50', '73900', '125.7 cm (50)', ' Ceramic Black', 'LED', '2', '2', 'No', 'No', 'Box', 'Yes', '1130 mm x 60 mm', '1 Year'),
(5, 'television', 'samsung', 'Samsung 126cm', 'samsung126cm', 'samsung126cm_1-1.jpeg', '50', '94900', '126 cm (50)', 'White', 'LED', '3', '2', 'No', 'No', 'Down Firing + Base Reflex', 'Yes', '1117.8 mm x 647.8 mm x 67.5 mm', '1 Year'),
(6, 'television', 'samsung', 'Samsung Series5', 'samsungseries5', 'samsungseries5_1-1.jpeg', '50', '118900', '125.7 cm (50)', 'Dark Titan', 'LED', '3', '2', 'Quad Core Processor', '16 GB', 'Box', 'Yes', '1241.6 mm x 721.4 mm x 55.1 mm', '1 Year'),
(7, 'television', 'sony', 'Sony 126cm', 'sony126cm', 'sony126cm_1-1.jpeg', '50', '65490', '126 cm (50)', ' Black', 'LED', '3', '2', 'No', '16 GB', 'Down Firing', 'Yes', '110.1 cm x 64.5 cm x 5.7 cm', '1 Year'),
(8, 'television', 'toshiba', 'Toshiba U50 Series', 'toshibau50series', 'toshibau50series_1-1.jpeg', '50', '35499', '125.7 cm (50)', 'Dark Titan', 'LED', '3', '2', 'Cortex-A53 64bit', '4 GB', 'Dolby Atmos, Dolby Audio', 'Yes', '111.6 cm x 64.7 cm x 8.5 cm', '1 Year');

-- --------------------------------------------------------

--
-- Table structure for table `55inches`
--

CREATE TABLE `55inches` (
  `id` int(50) NOT NULL,
  `gadget_type` varchar(50) NOT NULL,
  `model_type` varchar(50) NOT NULL,
  `model_name` varchar(30) NOT NULL,
  `folder_name` varchar(50) NOT NULL,
  `img_name` varchar(50) NOT NULL,
  `inches` varchar(50) NOT NULL,
  `prod_price` varchar(50) NOT NULL,
  `display_size` varchar(50) NOT NULL,
  `color` varchar(50) NOT NULL,
  `screen_type` varchar(50) NOT NULL,
  `hdmi` varchar(50) NOT NULL,
  `usb` varchar(50) NOT NULL,
  `processor` varchar(50) NOT NULL,
  `storage_memory` varchar(50) NOT NULL,
  `speaker_type` varchar(50) NOT NULL,
  `internet_access` varchar(50) NOT NULL,
  `dimension` varchar(50) NOT NULL,
  `Warranty` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `55inches`
--

INSERT INTO `55inches` (`id`, `gadget_type`, `model_type`, `model_name`, `folder_name`, `img_name`, `inches`, `prod_price`, `display_size`, `color`, `screen_type`, `hdmi`, `usb`, `processor`, `storage_memory`, `speaker_type`, `internet_access`, `dimension`, `Warranty`) VALUES
(1, 'television', 'lg', 'Lg Aanocell 139cm', 'lgnanocell139cm', 'lgnanocell139cm_1-1.jpeg', '55', '79499', '139 cm (55)', ' Black', 'LED', '4', '2', 'Quad Core Processor 4K', '8 GB', 'Smart Speaker Compatible', 'Yes', '123.2 cm x 71.6 cm x 6.36 cm', '1 Year'),
(2, 'television', 'oneplus', 'OnePlus Useries', 'oneplususeries', 'oneplususeries_1-1.jpeg', '55', '52999', ' 138.8 cm (55)', 'Black', 'LED', '3', '2', 'MTK 5670', '16 GB', 'Box', 'Yes', '1225.5 mm x 71 mm', '1 Year'),
(3, 'television', 'panasonic', 'Panasonic Fx730 Series', 'panasonicfx730series', 'panasonicfx730series_1-1.jpeg', '55', '65999', '139 cm (55)', ' Black', 'LED', '3', '3', 'No', 'No', 'Box Speakers', 'Yes', '1240 mm x 722 mm x 78 mm', '1 Year'),
(4, 'television', 'realme', 'Realme Sled', 'realmesled', 'realmesled_1-1.jpeg', '55', '40999', '139 cm (55)', 'Black', 'LED', '3', '2', '1.2 GHz Quad-Core Mediatek CPU', '16 GB', 'Box', 'Yes', '1229.7 mm x 713.5 mm x 65.9 mm', '1 Year'),
(5, 'television', 'samsung', 'Samsung 139cm', 'samsung139cm', 'samsung139cm_1-1.jpeg', '55', '86900', '139 cm (55)', ' Black', 'QLED', '3', '2', 'No', 'No', 'Box Speakers', 'Yes', '123 cm x 70.5 cm x 5.7 cm', '1 Year'),
(6, 'television', 'sansui', 'Sansui', 'sansui', 'sansui_1-1.jpeg', '55', '119990', '139 cm (55)', 'Black', 'LED', '3', '2', 'No', 'No', 'DTS Virtual:X', 'Yes', '98 mm', '1 Year'),
(7, 'television', 'sony', 'Sony W800g Series', 'sonyw800gseries', 'sonyw800gseries_1-1.jpeg', '55', '52999', '139 cm (55)', ' Black', 'LED', '4', '3', 'No', 'No', 'Box Speakers', 'Yes', '110.1 cm x 5.7 cm', '1 Year'),
(8, 'television', 'vupremium', 'Vupremium', 'vupremium', 'vupremium_1-1.jpeg', '55', '39999', '139 cm (55)', 'Black', 'LED', '3', '2', 'Quad Core Processor', '16 GB', 'Box', 'Yes', '136.4 cm x 83.1 cm x 16.6 cm', '1 Year');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
