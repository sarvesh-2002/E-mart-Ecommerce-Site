-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: May 23, 2021 at 04:20 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kitchen_appliance`
--

-- --------------------------------------------------------

--
-- Table structure for table `induction`
--

CREATE TABLE `induction` (
  `id` int(10) NOT NULL,
  `gadget_type` varchar(255) NOT NULL,
  `model_type` varchar(255) NOT NULL,
  `model_name` varchar(255) NOT NULL,
  `folder_name` varchar(255) NOT NULL,
  `img_name` varchar(255) NOT NULL,
  `prod_price` int(10) NOT NULL,
  `sales_package` varchar(255) NOT NULL,
  `power_required` varchar(255) NOT NULL,
  `highlight` varchar(255) NOT NULL,
  `body_material` varchar(255) NOT NULL,
  `weight` varchar(255) NOT NULL,
  `color` varchar(255) NOT NULL,
  `waranty` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `induction`
--

INSERT INTO `induction` (`id`, `gadget_type`, `model_type`, `model_name`, `folder_name`, `img_name`, `prod_price`, `sales_package`, `power_required`, `highlight`, `body_material`, `weight`, `color`, `waranty`) VALUES
(1, 'Kitchen Appliance', 'induction', 'BAJAJ ICX Pearl Induction Cooktop ', 'bajaj_icx', 'bajaj_icx_1_1.jpeg', 2664, '1 Main Unit', '1900 W', 'Push Button Controls', 'Ceramic', '1.2 Kg', 'Black', '1 Year '),
(2, 'Kitchen Appliance', 'induction', 'Prestige Atlas 2.0 Induction Cooktop ', 'prestige_atlas', 'prestige_atlas_2_1.jpeg', 2799, '1 Induction Cook top', '2000 W', 'Touch Panel Controls', 'Ceramic Top', '2.9 Kg', 'Black,Red', '1 Year'),
(3, 'Kitchen Appliance', 'induction', 'HAVELLS Insta Cook RT Induction Cooktop', 'havells_insta_cook', 'havells_insta_cook_3_1.jpeg', 2356, 'Induction', '1400 W', 'Worktop Material:Glass', 'Ceramic Top', '2.3 Kg', 'Black,Golden', '1 Year'),
(4, 'Kitchen Appliance', 'induction', 'USHA IC 3616 Induction Cooktop', 'usha_ic_3616', 'usha_ic_3616_4_1.jpeg', 2094, 'Induction cook top ', '220-240 v', 'Worktop Material:Glass,Push Button Controls', 'Ceramic Top', '2.5 kg', 'Black', '1 Year'),
(5, 'Kitchen Appliance', 'induction', 'Sansui Neutron 2100 W Induction Cooktop   ', 'sansui_neutron_2100_w', 'sansui_neutron_2100_w_5_1.jpeg', 2999, 'Induction Cooktop , User Manual', 'AC 220 - 230 V, 50 Hz', 'Worktop Material:Glass, Crystal', 'Crystal Polished Glass Top', '2.85 kg', 'Black,Gold', '1 Years'),
(6, 'Kitchen Appliance', 'induction', 'Prestige PIC 16.0 plus Induction Cooktop', 'prestige_pic_16_plus', 'prestige_pic_16_plus_6_1.jpeg', 2249, '1 Induction', '230 W', 'Push Button Controls', 'Ceramic', '1.7 kg', 'Black', '1 Years'),
(7, 'Kitchen Appliance', 'induction', 'PHILIPS HD4928/01 Induction Cooktop ', 'philips_hd4928', 'philips_hd4928_7_1.jpeg', 3099, 'User Manual, 1 Unit, Warranty Card', '220 - 240 V', 'Push Button Controls', 'Mirco Crystal Plate', '2.8 Kg', 'Black,Gold ', '1 Year'),
(8, 'Kitchen Appliance', 'induction', 'KENT 16058 Induction Cooktop', 'kent_16058', 'kent_16058_8_1.jpeg', 1900, '1 Induction Cooktop, User Manual', 'AC 220 - 240 V, 50 Hz', 'Worktop Material:Glass,Push Button Controls', 'Polypropylene Plastic', '1.65 Kg ', 'Black,Silver', '1 Year');

-- --------------------------------------------------------

--
-- Table structure for table `juicer`
--

CREATE TABLE `juicer` (
  `id` int(10) NOT NULL,
  `gadget_type` varchar(255) NOT NULL,
  `model_type` varchar(255) NOT NULL,
  `model_name` varchar(255) NOT NULL,
  `folder_name` varchar(255) NOT NULL,
  `img_name` varchar(255) NOT NULL,
  `prod_price` int(10) NOT NULL,
  `sales_package` varchar(255) NOT NULL,
  `power_required` varchar(255) NOT NULL,
  `highlight` varchar(255) NOT NULL,
  `depth` varchar(255) NOT NULL,
  `weight` varchar(255) NOT NULL,
  `color` varchar(255) NOT NULL,
  `waranty` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `juicer`
--

INSERT INTO `juicer` (`id`, `gadget_type`, `model_type`, `model_name`, `folder_name`, `img_name`, `prod_price`, `sales_package`, `power_required`, `highlight`, `depth`, `weight`, `color`, `waranty`) VALUES
(1, 'Kitchen Appliance', 'juicer', 'Mantavya Hand Juicer Grinder Fruit And Vegetable Mixer Juicer With Steel Handle 0 W Juicer', 'mantavya', 'mantavya_1_1.jpeg', 699, '1 Fruit and Vegetable Juicer Orange', 'NA', 'Hand Juicer : Juices without electricity, keeps juice fresh for the longest time', '6.75', '0.75 Kg', 'green', '10 Days '),
(2, 'Kitchen Appliance', 'juicer', 'Singer Nutri Blender NUTRIO (SPB 600 BNE) 300 W Juice', 'singer_nutri', 'singer_nutri_2_1.jpeg', 1741, '1 Nutri Blender, Tritan Jar, Mason Jar, Sipper Cap, Warranty Card, User Manual', '230 - 250 V', '300 W : Higher the Wattage, tougher the Juicing/Grinding', '14', '4 Kg', 'Black,white', '1 Year'),
(3, 'Kitchen Appliance', 'juicer', 'KENT KC-SJ502 250 W Juicer  ', 'kc_sj502', 'kc_sj502_3_1.jpeg', 8999, '1 Main Unit', 'AC 220 V, 50 Hz', 'Cold Press/ Slow Juicer : Uses less Power, extracts maximum juice and preserves nutrients', '41', '7.2 Kg', 'Black,white', '1 Year'),
(4, 'Kitchen Appliance', 'juicer', 'Bluwings Hand Juicer Grinder ABS Fruit & Vegetable Plastic Mixer Orange Hand Juicer 0 W Juicer', 'bluwings_hand', 'bluwings_hand_4_1.jpeg', 550, '1 Juicer ', 'NA', 'Hand Juicer : Juices without electricity, keeps juice fresh for the longest time', '6', '0.85 kg', 'Orange', '10 Days'),
(5, 'Kitchen Appliance', 'juicer', 'BMS Lifestyle JUICER Personal Mini Blender With Travel Sport Bottle 300 Juicer  ', 'bms_lifestyle', 'bms_lifestyle_5_1.jpeg', 1079, '1 JUICER 2 CUPS', 'On Charging', 'Centrifugal Juicer : Easy and quick juicing, ideal for larger fruits and veggies', '24', '1.5 kg', 'pink,black ', '1 Years'),
(6, 'Kitchen Appliance', 'juicer', 'PHILIPS HL1631/J 500 W Juicer', 'philips_hl1631', 'philips_hl1631_6_1.jpeg', 2590, 'Top Lid, User Manual, Juicer Blade, Base Motor', '230 W', '500 W : Higher the Wattage, tougher the Juicing/Grinding', '14.1', '0..5 kg', ' white', '2 Years'),
(7, 'Kitchen Appliance', 'juicer', 'Tom & Gee J 01 Fruit And Vegetable Mixer Hand Juicer 0 Juicer  ', 'tom_gee', 'tom_gee_7_1.jpeg', 501, '1 JUICER', 'NA', 'Hand Juicer : Juices without electricity, keeps juice fresh for the longest time', '8', '0.3 Kg', 'Green ', 'NA'),
(8, 'Kitchen Appliance', 'juicer', 'techobucks NA USB Rechargeable Portable Electric Fruit Juicer  ', 'techobucks', 'techobucks_8_1.jpeg', 515, '1 JUICER', 'On Charging', 'Centrifugal Juicer : Easy and quick juicing, ideal for larger fruits and veggies', '7.5', '0.3 Kg ', 'Pink', 'NA');

-- --------------------------------------------------------

--
-- Table structure for table `mixer`
--

CREATE TABLE `mixer` (
  `id` int(10) NOT NULL,
  `gadget_type` varchar(255) NOT NULL,
  `model_type` varchar(255) NOT NULL,
  `brand_name` varchar(255) NOT NULL,
  `model_name` varchar(255) NOT NULL,
  `folder_name` varchar(255) NOT NULL,
  `img_name` varchar(255) NOT NULL,
  `prod_price` int(10) NOT NULL,
  `sales_package` varchar(255) NOT NULL,
  `power_required` varchar(255) NOT NULL,
  `wattage` varchar(255) NOT NULL,
  `depth` varchar(255) NOT NULL,
  `weight` varchar(255) NOT NULL,
  `color` varchar(255) NOT NULL,
  `waranty` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `mixer`
--

INSERT INTO `mixer` (`id`, `gadget_type`, `model_type`, `brand_name`, `model_name`, `folder_name`, `img_name`, `prod_price`, `sales_package`, `power_required`, `wattage`, `depth`, `weight`, `color`, `waranty`) VALUES
(1, 'Kitchen Appliance', 'mixer', 'inalsa', 'Inalsa Jazz Plus 750 Mixer Grinder', 'inalsajazzplus', 'inalsajazzplus_1_1.jpeg', 5395, '1N Mixer Grinder, 1N SS Liquidizer Jar, 1N Liquidizer Jar Lid, 1N SS Dry Grinding Jar, 1N Dry Grinding Jar Lid, 1N SS Chutney Jar, 1N Chutney Jar Lid, 1N Spatula, 1N Instruction manual cum Warranty card', '230 V, 50 Hz', '750 : Higher the Wattage, tougher the Juicing/Grinding', '20.5', '2.7 Kg', 'White,Osion Blue', '1 Year'),
(2, 'Kitchen Appliance', 'mixer', 'bajaj', 'Bajaj GX1 500 W Mixer Grinder', 'bajaj_gx', 'Bajajgx_2_1.jpeg', 1799, '1 Unit with 3 jars', '50 HZ supply, 230 V', '500 W : Higher the Wattage, tougher the Juicing/Grinding', '31.4', '3.85 Kg', 'White,Blue', '1 Years'),
(3, 'Kitchen Appliance', 'mixer', 'butterfly', 'Butterfly Arrow 500 W Mixer Grinder ', 'butterfly_arrow', 'butterfly_arrow_3_1.jpeg', 1599, '1 Big jar with lid, 1 Chutney jar with Lid, 1 Mixer Unit, 1 Medium jar with lid, 1 Spatula and 1 User manual with Warranty Card.', 'AC 220-240V,50 Hz', '500 W : Higher the Wattage, tougher the Juicing/Grinding', '34.5', '3.15 Kg', 'Black', '1 Years'),
(4, 'Kitchen Appliance', 'mixer', 'philips', 'PHILIPS Daily Collection HL7756/03 750 W Mixer Grinder ', 'philips_hl7756', 'philips_hl7756_4_1.jpeg', 3199, '1 Mixer Grinder, Chutney Jar, Main Jar, Multipurpose Jar', '230 V, 50 Hz', '750 W : Higher the Wattage, tougher the Juicing/Grinding', '36.5', '3.2 kg', 'Pink', '2 Years'),
(5, 'Kitchen Appliance', 'mixer', 'bajaj', 'BAJAJ 3 Jar Pluto 500 W Mixer Grinder ', 'bajaj_pluto', 'bajaj_pluto_5_1.jpeg', 1899, '3 Jar, Warranty Card, 1 Main Unit, User manual', '70 W', '500 W : Higher the Wattage, tougher the Juicing/Grinding', '18', '1 kg', 'White ,Sky Blue', '1 Years'),
(6, 'Kitchen Appliance', 'mixer', 'powerchef', 'PowerChef Storm 500 W Mixer Grinder ', 'powerchef_storm', 'powerchef_storm_6_1.jpeg', 1694, '1 Mixer Grinder, Blending Jar, Dry Grinding Jar, Chutney Jar, 3 Blades, User Manual', '45 W', '500 W : Higher the Wattage, tougher the Juicing/Grinding', '25', '3.4 kg', 'White, Black', '2 Years'),
(7, 'Kitchen Appliance', 'mixer', 'prestige', 'Prestige Atlas 550 W Mixer Grinder ', 'prestige_atlas', 'prestige_atlas_7_1.jpeg', 3294, '1 mixer Grinder, 3 stainless steel jars', '70 W', '550 W : Higher the Wattage, tougher the Juicing/Grinding', '26.92', '4.9 Kg', 'White , Milk Blue', '1 Years'),
(8, 'Kitchen Appliance', 'mixer', 'eveready', 'EVEREADY MG500i 500 W Mixer Grinder', 'eveready_mg500i', 'eveready_mg500i_8_1.jpeg', 2499, '1 Dry Grinding Jar, 1 Chutney Jar, Warranty Card, Instruction Manual, 1 Liquidizing Jar, Main Unit', 'AC230-250V,50-60Hz', '500 W : Higher the Wattage, tougher the Juicing/Grinding', '24.53', '3.12 Kg ', 'White', '2 Years');

-- --------------------------------------------------------

--
-- Table structure for table `oven`
--

CREATE TABLE `oven` (
  `id` int(10) NOT NULL,
  `gadget_type` varchar(255) NOT NULL,
  `model_type` varchar(255) NOT NULL,
  `brand_name` varchar(255) NOT NULL,
  `model_name` varchar(255) NOT NULL,
  `folder_name` varchar(255) NOT NULL,
  `img_name` varchar(255) NOT NULL,
  `prod_price` int(10) NOT NULL,
  `sales_package` varchar(255) NOT NULL,
  `power_required` varchar(255) NOT NULL,
  `highlight` varchar(255) NOT NULL,
  `depth` varchar(255) NOT NULL,
  `weight` varchar(255) NOT NULL,
  `color` varchar(255) NOT NULL,
  `waranty` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `oven`
--

INSERT INTO `oven` (`id`, `gadget_type`, `model_type`, `brand_name`, `model_name`, `folder_name`, `img_name`, `prod_price`, `sales_package`, `power_required`, `highlight`, `depth`, `weight`, `color`, `waranty`) VALUES
(1, 'Kitchen Appliance', 'oven', 'godrej', 'Godrej 25 L Convection Microwave Oven', 'godrej25l', 'godrej25l_1_1.jpeg', 13049, 'Manual 1 Microwave Oven Startup Kit', '900 W AC 230 V, 50 Hz', 'Convection : Can be used for baking along with grilling, reheating, defrosting and cooking', '414', '15.11 Kg', 'Red, Black', '2 Year'),
(2, 'Kitchen Appliance', 'oven', 'samsung', 'SAMSUNG 28 L Convection Microwave Oven', 'samsung28l', 'samsung28l_2_1.jpeg', 16130, 'Wire Rack Crusty Plate Multi Spit Quick Guide Label 1 Microwave Oven', '900 w - 1500 w - AC 230 V, 50 Hz', 'Child Lock : Ensures complete safety especially for homes with small children', '47.56', '17.8 Kg', 'Black', '1 Years'),
(3, 'Kitchen Appliance', 'oven', 'haier', 'Haier 30 L Convection Microwave Oven ', 'haier30l', 'haier30l_3_1.jpeg', 14620, '1 Microwave Oven,Accessories(Turntable,Roller Ring),1 Instruction Manual,Pizza plate,Grill rack', '900 W - 2500 w - 230V~50Hz', 'Convection : Can be used for baking along with grilling, reheating, defrosting and cooking', '50.8', '18.9 Kg', 'Black', 'NA'),
(4, 'Kitchen Appliance', 'oven', 'samsung', 'SAMSUNG 23 L Solo Microwave Oven ', 'samsung23l', 'samsung23l_4_1.jpeg', 5577, '1 Turn Table & 1 User Manual with Warranty Card 1 Microwave Oven ', '800 w - 1150 W - AC 230 V, 50 Hz', 'Tact (Buttons), Jog Dial : Even with hands soiled with dough, these buttons can be used', '37.4', '12 kg', 'Black', 'NA'),
(5, 'Kitchen Appliance', 'oven', 'morphy', 'Morphy Richards 25 L Convection Microwave Oven ', 'morphyrichards25l', 'morphyrichards25l_5_1.jpeg', 11308, '1 Main Unit', '900 W', 'Feather Touch : Modern, easy-to-use touch controls', '35', '14.5 kg', 'silver ', '2 Years'),
(6, 'Kitchen Appliance', 'oven', 'morphy', 'Morphy Richards 20 L Grill Microwave Oven', 'morphyrichards20l', 'morphyrichards20l_6_1.jpeg', 7844, 'Microwave Oven', '800 W', 'Grill : Can be used for grilling along with defrosting, reheating and cooking food', '30', '13.4 kg', ' Black', '2 Years'),
(7, 'Kitchen Appliance', 'oven', 'bajaj', 'BAJAJ 17 L Solo Microwave Oven  ', 'bajaj17l', 'bajaj17l_7_1.jpeg', 4529, '1 Microwave Oven 1 User Manual with Warranty Card', '700 W', 'Mechanical Knob is an Easy-to-use Control that can have a long life', '51.99', '12.2 Kg', 'White ', '1 Years'),
(8, 'Kitchen Appliance', 'oven', 'lg', 'LG 20 L Solo Microwave Oven ', 'lg20l', 'lg20l_8_1.jpeg', 7499, 'User Manual Starter Kit 1 Microwave Oven', '700 W', 'Touch Key Pad (Membrane) is sensitive to touch and easy to clean', '320', '12 Kg ', 'black', 'NA');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
