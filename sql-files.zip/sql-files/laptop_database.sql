-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: May 23, 2021 at 04:19 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `laptop_database`
--

-- --------------------------------------------------------

--
-- Table structure for table `acer`
--

CREATE TABLE `acer` (
  `id` int(20) NOT NULL,
  `gadget_type` varchar(20) NOT NULL,
  `laptop_model` varchar(20) NOT NULL,
  `model_name` varchar(20) NOT NULL,
  `company_name` varchar(30) NOT NULL,
  `img_name` varchar(50) NOT NULL,
  `product_price` int(20) NOT NULL,
  `processor_brand` varchar(20) NOT NULL,
  `processor_name` varchar(20) NOT NULL,
  `processor_generation` varchar(20) NOT NULL,
  `ram` varchar(20) NOT NULL,
  `hard_disk_size` varchar(20) NOT NULL,
  `os_bit` varchar(20) NOT NULL,
  `operating_system` varchar(20) NOT NULL,
  `display_size` varchar(20) NOT NULL,
  `screen_resolution` varchar(20) NOT NULL,
  `waranty` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `acer`
--

INSERT INTO `acer` (`id`, `gadget_type`, `laptop_model`, `model_name`, `company_name`, `img_name`, `product_price`, `processor_brand`, `processor_name`, `processor_generation`, `ram`, `hard_disk_size`, `os_bit`, `operating_system`, `display_size`, `screen_resolution`, `waranty`) VALUES
(1, 'Laptop', 'acer', 'aceraspire3', 'Aspire 3', 'aceraspire3_1-1.jpeg', 29990, 'Ryzen', 'Ryzen 3', 'R series', '4GB', '1TB', '64 Bit', 'Windows 10 Home', '15.6 inch', '1364 x 764 pixels', '1 year Onsite'),
(2, 'Laptop', 'acer', 'aceraspire7', 'Aspire 7', 'aceraspire7_1-1.jpeg', 55990, 'Ryzen', 'Ryzen 5', '10th Gen', '8GB', '1TB', '64 Bit', 'Windows 10 Home', '15.6 inches', '1666 x 968 pixels', '1 year Onsite'),
(3, 'Laptop', 'acer', 'acernitro5', 'Nitro 5', 'acernitro5_1-1.jpeg', 74990, 'Intel Core', 'i5', '9th Gen', '8GB', '1TB', '64 Bit', 'Windows 10 Home', '17.3 inch', '1366 x 768 pixels', '1 year Onsite'),
(4, 'Laptop', 'acer', 'acerpredatorhelios', 'Predator Helios', 'acerpredator_1-1.jpeg', 109990, 'Intel Core', 'i7', '10th Gen', '16GB', '1TB', '64 Bit', 'Windows 10 Home', '15.6 inches', '1366 x 768 pixels', '1 year Onsite'),
(5, 'laptop', 'acer', 'aceraspire5', 'Aspire 5', 'aceraspire5_1-1.jpeg', 37990, 'Intel', 'Core i3', '10th Gen', ' 4 GB', '1TB', '64 Bit', 'Windows 10 Home', ' 35.56 cm (14 inch)', ' 1920 x 1080 Pixel', '1 year'),
(6, 'laptop', 'acer', 'acerconceptd', 'Concept D', 'acerconceptd_1-1.jpeg', 99500, ' Intel', ' Core i5', ' 8th Gen', '8GB', '1TB', '64 Bit', 'Windows 10 Home', '39.62 cm (15.6 inch)', '3840 x 2160 Pixel', '1 year'),
(7, 'laptop', 'acer', 'acerp2series', 'P2 Series', 'acerp2series_1-1.jpeg', 50990, 'Intel Core', 'i5', '11th Gen', '8GB', '1TB', '64 Bit', 'Windows 10 Home', '39.62 cm (15.6 inche', ' 1920 x 1080 Pixels', '1 year'),
(8, 'laptop', 'acer', 'acerswift3', 'Swift 3', 'acerswift3_1-1.jpeg', 59990, 'Intel', 'i5', '11th Gen', '8GB', '1TB', '64 Bit', 'Windows 10 Home', '34.29 cm (13.5 inch)', '1366 x 768 pixels', '1 year');

-- --------------------------------------------------------

--
-- Table structure for table `asus`
--

CREATE TABLE `asus` (
  `id` int(20) NOT NULL,
  `gadget_type` varchar(20) NOT NULL,
  `laptop_model` varchar(20) NOT NULL,
  `model_name` varchar(20) NOT NULL,
  `company_name` varchar(30) NOT NULL,
  `img_name` varchar(50) NOT NULL,
  `product_price` int(20) NOT NULL,
  `processor_brand` varchar(20) NOT NULL,
  `processor_name` varchar(20) NOT NULL,
  `processor_generation` varchar(20) NOT NULL,
  `ram` varchar(20) NOT NULL,
  `hard_disk_size` varchar(20) NOT NULL,
  `os_bit` varchar(20) NOT NULL,
  `operating_system` varchar(20) NOT NULL,
  `display_size` varchar(20) NOT NULL,
  `screen_resolution` varchar(20) NOT NULL,
  `waranty` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `asus`
--

INSERT INTO `asus` (`id`, `gadget_type`, `laptop_model`, `model_name`, `company_name`, `img_name`, `product_price`, `processor_brand`, `processor_name`, `processor_generation`, `ram`, `hard_disk_size`, `os_bit`, `operating_system`, `display_size`, `screen_resolution`, `waranty`) VALUES
(1, 'Laptop', 'asus', 'asusexpertbook', 'Expertbook', 'asusexpertbook_1-1.jpeg', 29990, 'Intel Core', 'i3', '10th Gen', '4GB', '1TB', '64 Bit', 'Windows 10 Home', '14 inch', '1366 x 768 pixels', '1 year Onsite'),
(2, 'Laptop', 'asus', 'asusrogstrix', 'Rogstrix', 'asusrogstrix_1-1.jpeg', 102990, 'Intel Core', 'i7', '10th Gen', '16GB', '1TB', '64 Bit', 'Windows 10 Home', '15.6 inches', '1366 x 768 pixels', '1 year Onsite'),
(3, 'Laptop', 'asus', 'asustufgaming', 'Stufgaming', 'asustufgaming_1-1.jpeg', 76990, 'Intel Core', 'i5', '9th Gen', '8GB', '1TB', '64 Bit', 'Windows 10 Home', '15.6 inch', '1364 x 764 pixels', '1 year Onsite'),
(4, 'Laptop', 'asus', 'asusvivobook15', 'Vivobook 15', 'asusvivobook15_1-1.jpeg', 42990, 'Intel Core', 'i5', '10th Gen', '8GB', '1TB', '64 Bit', 'Windows 10 Home', '15.6 inches', '1666 x 968 pixels', '1 year Onsite'),
(5, 'laptop', 'asus', 'asusceleron', 'Celeron', 'asusceleron_1-1.jpeg', 20990, 'Intel', 'Celeron Dual Core', '10th Gen', '4GB', '1TB', '64 Bit', 'Windows 10 Home', ' 39.62 cm (15.6 inch', '1366 x 768 pixels', '1 year'),
(6, 'laptop', 'asus', 'asuscorei5', 'Core I5', 'asuscorei5_1-1.jpeg', 53990, 'Intel', 'Core i5', '10th Gen', '8GB', '1TB', '64 Bit', 'Windows 10 Home', ' 39.62 cm (15.6 inch', ' 1920 x 1080 Pixel', '1 year'),
(7, 'laptop', 'asus', 'asusprop5', 'Prop5', 'asusprop5_1-1.jpeg', 98912, 'Intel', ' Core i7', '8th Gen', '8GB', '1TB', '64 Bit', 'Windows 10 Home', '35.56 cm (14 inch)', '1366 x 768 pixels', '1 year'),
(8, 'laptop', 'asus', 'asuszenbook13', 'Zenbook 13', 'asuszenbook13_1-1.jpeg', 75990, 'Intel Core', 'i5', '10th Gen', '8GB', '1TB', '64 Bit', 'Windows 10 Home', '33.02 cm (13 inch)', ' 1920 x 1080 Pixel', '1 year');

-- --------------------------------------------------------

--
-- Table structure for table `dell`
--

CREATE TABLE `dell` (
  `id` int(20) NOT NULL,
  `gadget_type` varchar(20) NOT NULL,
  `laptop_model` varchar(20) NOT NULL,
  `model_name` varchar(20) NOT NULL,
  `company_name` varchar(30) NOT NULL,
  `img_name` varchar(50) NOT NULL,
  `product_price` int(20) NOT NULL,
  `processor_brand` varchar(20) NOT NULL,
  `processor_name` varchar(20) NOT NULL,
  `processor_generation` varchar(20) NOT NULL,
  `ram` varchar(20) NOT NULL,
  `hard_disk_size` varchar(20) NOT NULL,
  `os_bit` varchar(20) NOT NULL,
  `operating_system` varchar(20) NOT NULL,
  `display_size` varchar(20) NOT NULL,
  `screen_resolution` varchar(20) NOT NULL,
  `waranty` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `dell`
--

INSERT INTO `dell` (`id`, `gadget_type`, `laptop_model`, `model_name`, `company_name`, `img_name`, `product_price`, `processor_brand`, `processor_name`, `processor_generation`, `ram`, `hard_disk_size`, `os_bit`, `operating_system`, `display_size`, `screen_resolution`, `waranty`) VALUES
(1, 'Laptop', 'dell', 'dellg3', 'G3', 'dellg3_1-1.jpeg', 88990, 'Intel Core', 'i7', '10th Gen', '16GB', '1TB', '64 Bit', 'Windows 10 Home', '15.6 inch', '1366 x 768 pixels', '1 year Onsite'),
(2, 'Laptop', 'dell', 'dellinspiron3505', 'Inspiron 3505', 'dellinspiron3505_1-1.jpeg', 32517, 'Ryzen', 'Ryzen 3', '11th Gen', '8GB', '1TB', '64 Bit', 'Windows 10 Home', '15.6 inches', '1366 x 768 pixels', '1 year Onsite'),
(3, 'Laptop', 'dell', 'delllatitude3400', 'Latitude 3400', 'delllatitude3400_1-1.jpeg', 59990, 'Intel Core', 'i5', '8th Gen', '8GB', '1TB', '64 Bit', 'Windows 10 Pro', '14 inch', '1366 x 768 pixels', '1 year Onsite'),
(4, 'Laptop', 'dell', 'dellvostro3405', 'Vostro 3405', 'dellvostro3405_1-1.jpeg', 42499, 'Ryzen', 'Ryzen 5', '11th Gen', '8GB', '1TB', '64 Bit', 'Windows 10 Home', '14 inches', '1366 x 768 pixels', '1 year Onsite'),
(5, 'laptop', 'dell', 'dellg5', 'G5', 'dellg5_1-1.jpeg', 75990, 'AMD', ' Ryzen 5 Hexa Core', 'No', '8GB', '1TB', '64 Bit', 'Windows 10 Home', '39.62 cm (15.6 inch)', ' 1920 x 1080 Pixel', '1 year'),
(6, 'laptop', 'dell', 'dellg7', 'G7', 'dellg7_1-1.jpeg', 207990, 'Intel', 'Core i9', '10th Gen', '16GB', '1TB', '64 Bit', 'Windows 10 Home', ' 39.62 cm (15.6 inch', ' 1920 x 1080 Pixel', '1 year'),
(7, 'laptop', 'dell', 'dellinspironcorei5', 'Inspiron Core I5', 'dellinspironcorei5_1-1.jpeg', 59290, 'Intel', 'i5', '11th Gen', '8GB', '1TB', '64 Bit', 'Windows 10 Home', ' 35.56 cm (14 inch)', ' 1920 x 1080 Pixel', '1 year'),
(8, 'laptop', 'dell', 'dellxps', 'Xps', 'dellxps_1-1.jpeg', 202740, 'Intel', 'i7', '10th Gen', '16GB', '1TB', '64 Bit', 'Windows 10 Home', ' 39.62 cm (15.6 inch', '3840 x 2160 Pixel', '1 year Onsite');

-- --------------------------------------------------------

--
-- Table structure for table `hp`
--

CREATE TABLE `hp` (
  `id` int(20) NOT NULL,
  `gadget_type` varchar(20) NOT NULL,
  `laptop_model` varchar(20) NOT NULL,
  `model_name` varchar(20) NOT NULL,
  `company_name` varchar(30) NOT NULL,
  `img_name` varchar(50) NOT NULL,
  `product_price` int(20) NOT NULL,
  `processor_brand` varchar(20) NOT NULL,
  `processor_name` varchar(20) NOT NULL,
  `processor_generation` varchar(20) NOT NULL,
  `ram` varchar(20) NOT NULL,
  `hard_disk_size` varchar(20) NOT NULL,
  `os_bit` varchar(20) NOT NULL,
  `operating_system` varchar(20) NOT NULL,
  `display_size` varchar(20) NOT NULL,
  `screen_resolution` varchar(20) NOT NULL,
  `waranty` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `hp`
--

INSERT INTO `hp` (`id`, `gadget_type`, `laptop_model`, `model_name`, `company_name`, `img_name`, `product_price`, `processor_brand`, `processor_name`, `processor_generation`, `ram`, `hard_disk_size`, `os_bit`, `operating_system`, `display_size`, `screen_resolution`, `waranty`) VALUES
(1, 'Laptop', 'hp', 'hp14s', '14s', 'hp14s_1-1.jpeg', 58990, 'Intel Core', 'i5', '10th Gen', '8GB', '1TB', '64 Bit', 'Windows 10 Home', '14 inch', '1366 x 768 pixels', '1 year Onsite'),
(2, 'Laptop', 'hp', 'hp15', '15', 'hp15_1-1.jpeg', 38490, 'Intel Core', 'i3', '11th Gen', '8GB', '1TB', '64 Bit', 'Windows 10 Home', '15.6 inches', '1366 x 768 pixels', '1 year Onsite'),
(3, 'Laptop', 'hp', 'hpnotebook', 'Notebook', 'hpnotebook_1-1.jpeg', 24686, 'Intel Core', 'Athlon 64 3000+', 'R series', '4GB', '1TB', '64 Bit', 'Windows 10 Home', '14 inch', '1364 x 764 pixels', '1 year Onsite'),
(4, 'Laptop', 'hp', 'hppavilion2021', 'Pavilion 2021', 'hppavilion2021_1-1.jpeg', 38490, 'Intel Core', 'i7', '11th Gen', '8GB', '1TB', '64 Bit', 'Windows 10 Home', '14 inches', '1366 x 768 pixels', '1 year Onsite'),
(5, 'laptop', 'hp', 'hpenvyx360', 'Envy x360', 'hpenvyx360_1-1.jpeg', 74990, 'AMD', 'Ryzen 5 Hexa Core', '10th Gen', '8GB', '1TB', '64 Bit', 'Windows 10 Home', ' 33.78 cm (13.3 inch', ' 1920 x 1080 Pixel', '1 year'),
(6, 'laptop', 'hp', 'hpomen15', 'Omen 15', 'hpomen15_1-1.jpeg', 69990, ' AMD', 'Ryzen 5', 'No', '8GB', '1TB', '64 Bit', 'Windows 10 Home', '39.62 cm (15.6 inch)', ' 1920 x 1080 Pixel', '1 year'),
(7, 'laptop', 'hp', 'hppaviliongaming', 'Pavilion Gaming', 'hppaviliongaming_1-1.jpeg', 49990, 'AMD', 'Ryzen 5 Quad Core', 'No', '8GB', '1TB', '64 Bit', 'Windows 10 Home', '39.62 cm (15.6 inch)', ' 1920 x 1080 Pixel', '1 year'),
(8, 'laptop', 'hp', 'hpryzen5', 'Ryzen 5', 'hpryzen5_1-1.jpeg', 34890, ' AMD', ' Ryzen 5 Quad Core', 'No', '4GB', '1TB', '64 Bit', 'Windows 10 Home', '35.56 cm (14 inch)', '1366 x 768 pixels', '1 year');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
