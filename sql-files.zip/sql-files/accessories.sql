-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: May 23, 2021 at 04:21 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `accessories`
--

-- --------------------------------------------------------

--
-- Table structure for table `cables`
--

CREATE TABLE `cables` (
  `Id` int(50) NOT NULL,
  `Gadget_Type` varchar(50) NOT NULL,
  `Model_Type` varchar(50) NOT NULL,
  `Model_Name` varchar(50) NOT NULL,
  `Product_Model` varchar(50) NOT NULL,
  `Folder_Name` varchar(50) NOT NULL,
  `Img_Name` varchar(50) NOT NULL,
  `Length` varchar(50) NOT NULL,
  `Cable_Type` varchar(50) NOT NULL,
  `Cable_Speed` varchar(50) NOT NULL,
  `Connector_One` varchar(50) NOT NULL,
  `Connector_Two` varchar(50) NOT NULL,
  `Price` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cables`
--

INSERT INTO `cables` (`Id`, `Gadget_Type`, `Model_Type`, `Model_Name`, `Product_Model`, `Folder_Name`, `Img_Name`, `Length`, `Cable_Type`, `Cable_Speed`, `Connector_One`, `Connector_Two`, `Price`) VALUES
(1, 'Accessories', 'mobilecables', 'ambraneacm', 'Ambrane Acm', 'ambrane-acm', 'ambraneacm_1.jpeg', '1 m', 'Round Cable', '480 Mbps', 'USB', 'Micro - USB', 149),
(2, 'Accessories', 'mobilecables', 'boatmicro', 'Boat Micro', 'boatmicro', 'boatmicro_1.jpeg', '1.5 m', 'Round Cable', '480 Mbps', 'A Type', 'Micro - USB', 269),
(3, 'Accessories', 'mobilecables', 'chronorex', 'Chrono Rex', 'chronorex', 'chronorex_1.jpeg', '1 m', 'Round Cable', '480 Mbps', 'Lightning Type', 'USB Type', 179),
(4, 'Accessories', 'mobilecables', 'flipkartsmartbuy', 'Flipkart Smartbuy', 'flipkart-smartbuy', 'flipkartsmartbuy_1.jpeg', '1 m', 'Round Cable', '480 Mbps', 'USB', 'Micro - USB', 139),
(5, 'Accessories', 'mobilecables', 'vivocables', 'Vivo Cables', 'vivo-cables', 'vivocables_1.jpeg', '1 m', 'Round Cable', '400 Mbps', 'MICRO', 'USB ', 164),
(6, 'Accessories', 'mobilecables', 'redmioriginal', 'Redmi Original', 'redmi-original', 'redmioriginal_1.jpeg', '1.2 m', 'Round Cable', '480 Mbps', 'A Type', 'Micro - USB', 199),
(7, 'Accessories', 'mobilecables', 'portronics', 'Portronics', 'portronics', 'portronics_1.jpeg', '1 m', 'Round Cable', '400 Mbps', 'USB', 'Type C', 149),
(8, 'Accessories', 'mobilecables', 'mivi6ft', 'Mivi 6ft', 'mivi6ft', 'mivi6ft_1.jpeg', '1.8 m', 'Round Cable', '480 Mbps', 'Micro - USB', 'USB', 149);

-- --------------------------------------------------------

--
-- Table structure for table `chargers`
--

CREATE TABLE `chargers` (
  `Id` int(50) NOT NULL,
  `Gadget_Type` varchar(50) NOT NULL,
  `Model_Type` varchar(50) NOT NULL,
  `Model_Name` varchar(50) NOT NULL,
  `Product_Model` varchar(50) NOT NULL,
  `Folder_Name` varchar(50) NOT NULL,
  `Img_Name` varchar(50) NOT NULL,
  `Cable_Length` varchar(50) NOT NULL,
  `Charger_Type` varchar(50) NOT NULL,
  `Output_Current` varchar(50) NOT NULL,
  `Output_Wattage` varchar(50) NOT NULL,
  `Price` int(20) NOT NULL,
  `Warranty` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `chargers`
--

INSERT INTO `chargers` (`Id`, `Gadget_Type`, `Model_Type`, `Model_Name`, `Product_Model`, `Folder_Name`, `Img_Name`, `Cable_Length`, `Charger_Type`, `Output_Current`, `Output_Wattage`, `Price`, `Warranty`) VALUES
(1, 'Accessories', 'mobilecharger', 'ambraneaqc', 'Ambrane Aqc', 'ambrane-aqc', 'ambraneaqc_1.jpeg', '1.2 m', 'Wall Charger', '3 A', '18 W', 406, 'NA'),
(2, 'Accessories', 'mobilecharger', 'musttalk', 'Must Talk', 'musttalk', 'musttalk_1.jpeg', '1 m', 'Wall Charger ', '2.4 A', '5 W', 324, '1 Year'),
(3, 'Accessories', 'mobilecharger', 'oppo2.4', 'Oppo 2.4', 'oppo2.4', 'oppo2.4_1.jpeg', '1 m', 'Wall Charger', '2.4 A', '18 W', 349, '1 Year'),
(4, 'Accessories', 'mobilecharger', 'phillipsdlp2501b', 'Phillips Dlp 2501b', 'phillips-dlp2501b', 'phillipsdlp2501b_1.jpeg', '1 m', 'Wall Charger ', '2.1 A', '10.5 W', 268, 'NA'),
(5, 'Accessories', 'mobilecharger', 'redmistandard', 'Redmi Standard', 'redmi-standard', 'redmistandard_1.jpeg', '1.2 m', 'Wall Charger', '2 A', '10 W', 499, '6 Months'),
(6, 'Accessories', 'mobilecharger', 'flipkartsmartbuy', 'Flipkart Smart Buy', 'flipkart-smartbuy10w', 'flipkartsmartbuy10w_1.jpeg', '1 m', 'Wall Charger ', '2 A', '10 W', 299, '6 Months'),
(7, 'Accessories', 'mobilecharger', 'syskawc', 'Syska Wc', 'syska-wc', 'syskawc_1.jpeg', '1 m', 'Wall Charger', '2 A', '10 W', 349, '6 Months'),
(8, 'Accessories', 'mobilecharger', 'vivofast', 'Vivo Fast', 'vivo-fast', 'vivofast_1.jpeg', '1 m', 'Wall Charger ', '4.2 A', '18 W', 430, 'Not Available');

-- --------------------------------------------------------

--
-- Table structure for table `earphones`
--

CREATE TABLE `earphones` (
  `Id` int(50) NOT NULL,
  `Gadget_Type` varchar(50) NOT NULL,
  `Model_Type` varchar(50) NOT NULL,
  `Model_Name` varchar(50) NOT NULL,
  `Product_Model` varchar(50) NOT NULL,
  `Folder_Name` varchar(50) NOT NULL,
  `Img_Name` varchar(50) NOT NULL,
  `With_Mic` varchar(50) NOT NULL,
  `Connector_Type` varchar(50) NOT NULL,
  `Bluetooth` varchar(50) NOT NULL,
  `Water_Resistant` varchar(50) NOT NULL,
  `Battery` varchar(50) NOT NULL,
  `Price` int(20) NOT NULL,
  `Warranty` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `earphones`
--

INSERT INTO `earphones` (`Id`, `Gadget_Type`, `Model_Type`, `Model_Name`, `Product_Model`, `Folder_Name`, `Img_Name`, `With_Mic`, `Connector_Type`, `Bluetooth`, `Water_Resistant`, `Battery`, `Price`, `Warranty`) VALUES
(1, 'Accessories', 'earphones', 'boatbassheads', 'Boat Bassheads', 'boat-bassheads', 'boatbassheads_1.jpeg', 'Yes', '3.5 mm', 'No Bluetooth', 'No', 'No', 349, '1 Year'),
(2, 'Accessories', 'earphones', 'boatrockerz', 'Boat Rockerz', 'boat-rockerz', 'boatrockerz_1.jpeg', 'Yes', 'No', 'Version 5.0', 'Yes', '8 Hours', 1099, '1 Year'),
(3, 'Accessories', 'earphones', 'boultaudio', 'Boult Audio', 'boult-audio', 'boultaudio_1.jpeg', 'Yes', '3.5 mm', 'No Bluetooth', 'Yes', 'No', 299, '1 Year'),
(4, 'Accessories', 'earphones', 'catbull', 'Cat Bull', 'catbull', 'catbull_1.jpeg', 'Yes', 'No', 'Yes', 'Yes', '1  Hour', 167, 'Not Available'),
(5, 'Accessories', 'earphones', 'oneplusbullets', 'Oneplus Bullets', 'oneplus-bullets', 'oneplusbullets_1.jpeg', 'Yes', 'No', 'Version 5.0', 'Yes', '20 Hours', 1999, '1 Year'),
(6, 'Accessories', 'earphones', 'orhox', 'Orhox', 'orhox', 'orhox_1.jpeg', 'Yes', 'No', 'Version 5', 'Yes', '2  Hour', 167, 'Not Available'),
(7, 'Accessories', 'earphones', 'realmebuds', 'Realme Buds', 'realme-buds', 'realmebuds_1.jpeg', 'Yes', '3.5 mm', 'No Bluetooth', 'No', 'No', 399, '6 Months'),
(8, 'Accessories', 'earphones', 'redmisonicbass', 'Redmi Sonic Bass', 'redmi-sonicbass', 'redmisonicbass_1.jpeg', 'Yes', 'No', 'Version 5', 'Yes', '8 Hours', 1599, '1 Year');

-- --------------------------------------------------------

--
-- Table structure for table `pendrive`
--

CREATE TABLE `pendrive` (
  `Id` int(50) NOT NULL,
  `Gadget_Type` varchar(50) NOT NULL,
  `Model_Type` varchar(50) NOT NULL,
  `Model_Name` varchar(50) NOT NULL,
  `Product_Model` varchar(50) NOT NULL,
  `Folder_Name` varchar(50) NOT NULL,
  `Img_Name` varchar(50) NOT NULL,
  `USB` varchar(50) NOT NULL,
  `Storage_Capacity` varchar(50) NOT NULL,
  `Material_used` varchar(50) NOT NULL,
  `Price` int(20) NOT NULL,
  `Warranty` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pendrive`
--

INSERT INTO `pendrive` (`Id`, `Gadget_Type`, `Model_Type`, `Model_Name`, `Product_Model`, `Folder_Name`, `Img_Name`, `USB`, `Storage_Capacity`, `Material_used`, `Price`, `Warranty`) VALUES
(1, 'Accessories', 'pendrive', 'sandiskcruzerblade', 'Sandisk Cruzer Blade', 'sandiskcruzer', 'sandiskcruzer_1.jpeg', '2.0', '32 GB', 'Plastic', 399, '5 Years'),
(2, 'Accessories', 'pendrive', 'hpv220w', 'Hpv 220w', 'hpv220w', 'hpv220w_1.jpeg', '2.0', '64 GB', 'Metal', 482, '1 Year'),
(3, 'Accessories', 'pendrive', 'sandisksddd3', 'Sandisk Sdd d3', 'sandisksddd3', 'sandisksddd3_1.jpeg', '3.0', '64 GB', 'Plastic', 797, '5 Years'),
(4, 'Accessories', 'pendrive', 'hpv236w', 'Hpv 236w', 'hpv236w', 'hpv236w_1.jpeg', '2.0', '32 GB', 'Metal', 415, '1 Year'),
(5, 'Accessories', 'pendrive', 'sony', 'Sony', 'sony', 'sony_1.jpeg', '2.0', '64 GB', 'Plastic', 865, '5 Years'),
(6, 'Accessories', 'pendrive', 'strontiumnitroammo', 'Strontium Nitro Ammo', 'strontium-nitro', 'strontiumnitroammo_1.jpeg', '3.1', '32 GB', 'Metal', 575, '5 Year');

-- --------------------------------------------------------

--
-- Table structure for table `powerbank`
--

CREATE TABLE `powerbank` (
  `Id` int(50) NOT NULL,
  `Gadget_Type` varchar(50) NOT NULL,
  `Model_Type` varchar(50) NOT NULL,
  `Model_Name` varchar(50) NOT NULL,
  `Product_Model` varchar(50) NOT NULL,
  `Folder_Name` varchar(50) NOT NULL,
  `Img_Name` varchar(50) NOT NULL,
  `Power_Source` varchar(50) NOT NULL,
  `Charging_Cable` varchar(50) NOT NULL,
  `Weight` varchar(50) NOT NULL,
  `Capacity` varchar(20) NOT NULL,
  `Battery_Type` varchar(20) NOT NULL,
  `Price` int(20) NOT NULL,
  `Warranty` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `powerbank`
--

INSERT INTO `powerbank` (`Id`, `Gadget_Type`, `Model_Type`, `Model_Name`, `Product_Model`, `Folder_Name`, `Img_Name`, `Power_Source`, `Charging_Cable`, `Weight`, `Capacity`, `Battery_Type`, `Price`, `Warranty`) VALUES
(1, 'Accessories', 'powerbank', 'ambrane', 'Ambrane', 'ambrane', 'ambrane_1.jpeg', 'AC Adapter', 'Included', '434 g', '10000 mAh', 'Polymer Lithium Batt', 694, '6 Months'),
(2, 'Accessories', 'powerbank', 'mi3i', 'Mi3i', 'mi3i', 'mi3i_1.jpeg', 'Battery', 'Included', '434 g', '20000 mAh', 'Lithium Polymer Batt', 1599, 'NA'),
(3, 'Accessories', 'powerbank', 'oneplus', 'Oneplus', 'oneplus', 'oneplus_1.jpeg', 'AC Adapter', 'Included', '400 g', '10000 mAh', 'Polymer Lithium ', 1099, '1 Year'),
(4, 'Accessories', 'powerbank', 'realme', 'Realme', 'realme', 'realme_1.jpeg', 'Battery', 'Included', '250 g', '10000 mAh', 'Lithium Polymer ', 999, '1 Year'),
(5, 'Accessories', 'powerbank', 'syskapowerbank', 'Syska', 'syska', 'syska_1.jpeg', 'Rechargeable Battery', 'Included', '200 g', '10000 mAh', 'Lithium Polymer ', 649, '6 Months'),
(6, 'Accessories', 'powerbank', 'redmipowerbank', 'Redmi', 'redmi', 'redmi_1.jpeg', 'Battery', 'Included', '246.5 g', '10000 mAh', 'Lithium Polymer ', 799, '6 Months'),
(7, 'Accessories', 'powerbank', 'intex', 'Intex', 'intex', 'intex_1.jpeg', 'USB', 'Included', '408 g', '20000 mAh', 'Lithium Polymer ', 1099, '6 Months'),
(8, 'Accessories', 'powerbank', 'iballpowerbank', 'Iball', 'iball', 'iball_1.jpeg', 'AC Adapter, USB', 'Included', '199 g', '10000 mAh', 'Lithium Polymer ', 590, '1 Year');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
