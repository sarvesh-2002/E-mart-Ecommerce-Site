<?php 
	session_destroy();
?>