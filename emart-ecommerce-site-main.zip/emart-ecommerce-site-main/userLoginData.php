<?php  

	// emart_user_data
	$createconn = mysqli_connect("localhost","root",'',"emart_user_data");
	// conn
	$conn = mysqli_connect("localhost","root",'',"emart_login_data");
	// admin
	$adminconn = mysqli_connect("localhost","root",'',"admin_user_data");

	$db_name = $_POST['uname'];
	$ID = $_POST['userid'];
	$mail = $_POST['umail'];
	$pass = $_POST['upass'];

	$sql1 = "UPDATE user_data SET email='$mail' , password='$pass' WHERE id = $ID";
	$a = mysqli_query($adminconn,$sql1);

	$sql2 = "UPDATE $db_name SET email='$mail' , password='$pass' WHERE id = 1";
	$b = mysqli_query($createconn,$sql2);

	$sql3 = "UPDATE login_credentials SET email='$mail' , password='$pass' WHERE username = '$db_name'";
	$c = mysqli_query($conn,$sql3);

	if($a && $b && $c)
	{
		header("location:userProfile.php");
	}
?>