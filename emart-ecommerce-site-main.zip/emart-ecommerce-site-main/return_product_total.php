<?php  

	$host = 'localhost';
	$user = "root";
	$pass = '';
	$db = "autocomplete_textbox";

	$conn = mysqli_connect($host,$user,$pass,$db);

	$search_item = $_POST["prod_name"];

	$sql = "SELECT DISTINCT(Product) FROM ajax_autocomplete_textbox WHERE Product LIKE '$search_item%'";
	$res = mysqli_query($conn,$sql);

	if(mysqli_num_rows($res)>0)
	{
		echo 1;
	}

	else
	{
		echo 0;
	}
?>
